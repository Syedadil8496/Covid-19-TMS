 <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                   <!--     <span>Copyright &copy; covid19-TMS 2021 || Powered by <a href="http://rcsinfo.in">RCS Technology</a> </span>-->
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->