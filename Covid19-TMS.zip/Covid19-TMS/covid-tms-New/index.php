<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="RCS Technology">

  <title>Covid-19 Testing Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">Covid19-Testing</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About Coronavirus </a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Covid-19 Symptoms</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Prevention</a>
          </li>
  <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="new-user-testing.php">Testing</a>
          </li>
           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="live-test-updates.php">Live Updates</a>
          </li>

           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="login.php">Admin</a>
          </li>


        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white" style="background-image: url(./img/covidbanner.jpg); background-repeat: no-repeat; background-size: cover;">
    <div class="container text-center" style="color: #000000;">
      <h1>COVID19- Testing</h1>
      <p class="lead">Stay Home, Stay Safe - Stop the Spread of Corona Virus</p>
    </div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>About Corona Virus</h2>
          <p class="lead">Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus. Most people infected with the COVID-19, virus will experience mild to moderate, respiratory illness & recover without requiring special treatment. Older people and those with underlying medical problem like cardiovascular disease.</p>
          <p class="lead">The COVID-19 virus spread primarily through droplet of saliva or discharge from the nose when an infected person coughs or sneezes so it’s important that you also practice respiratory etiquette.</p>
         
        </div>
        <div class="col-lg-4 ">
          <img src="./img/cov1.jpg" width="350">
        </div>
      </div>
    </div>
  </section>

  <section id="services" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Covid-19 Symptoms</h2>
          <hr />
<p><strong>Hight Fever 2-14 days!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
             <hr />
<p><strong>Dry Cough 2-14 days!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
          <hr />
<p><strong>Shortness of breath!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
        </div>
      </div>
    </div>
  </section>

  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Prevention</h2>
          <ul>
            <li>Stay home if you feel unwell.</li>
            <li>Don’t touch your eyes, nose or mouth.</li>
            <li>Wear a mask when physical distancing is not possible.</li>
            <li>Maintain a safe distance from anyone who is coughing or sneezing.</li>
            <li>Clean your hands often. Use soap and water, or an alcohol-based hand rub.</li>
            <li>If you have a fever, cough and difficulty breathing, seek medical attention.</li>
            <li>Cover your nose and mouth with your bent elbow or a tissue when you cough or sneeze.</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
     <p class="m-0 text-center text-white">Project done by <a href="https://github.com/Syedadil8496">SYED ADIL</a> </p>
     <p class="m-0 text-center text-white">Project done by <a href="https://github.com/Syedadil8496">RAKSHITH M</a> </p>

     
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
