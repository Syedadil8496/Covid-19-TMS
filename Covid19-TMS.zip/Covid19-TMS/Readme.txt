

Admin Credential
Username: admin
Password: Test@123